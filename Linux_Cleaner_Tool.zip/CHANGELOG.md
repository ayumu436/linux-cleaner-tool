# Changelog

## v1.0.0 - Initial Release
- Added:
  - Scan Only Mode
  - Dry Run Mode
  - Clean All and Custom Cleanup
  - Backup and Restore Functionality
  - Detailed Logging and Error Handling
  - Support for User and System Cache, Logs, and Temporary Files
